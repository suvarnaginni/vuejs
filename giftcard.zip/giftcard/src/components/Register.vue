<template>
  <div>
    <h1>{{ msg }}</h1>
     <div>
         <span v-if="statusmessages.length" v-bind:class="[isSuccess? 'successmessage': 'errormessage']">
             <span v-for="(message, index) in statusmessages" v-bind:key="index">
                 {{message}}
             </span>
         </span>
     </div>
     <form >
        <label>Username</label>
        <input type="text" v-model.lazy="user.username"  required>
        <br>
        <label>Password:</label>
        <input type="text"  v-model.lazy="user.password"  required>
        <br>
        <label>Confirm Password:</label>
        <input type="text" required>
        <br>
         <label>Email:</label>
        <input type="text"  v-model.lazy="user.email"  required>
        <br>
         <button v-on:click.prevent="registration()">Register</button>
      </form>
  </div>
</template>

<script>
export default {
  name: 'Register',
  data: function(){
    return {
      msg: 'Registration!!!!',
      user: {
          "userid":0,
          "username":"",
          "password":"",
          "email":""
      },
      statusmessages:[],
      isSuccess:true
    }
  },
  methods:{
      registration : function(){
          this.statusmessages=[];
          let validity= this.validateinputs();
          if(validity){
              this.$http.post('https://my-json-server.typicode.com/suvarnaginni/jsondata/db/users', this.user) 
                    .then(
                        res=>{
                            console.log(res)
                            //this.$router.push({path:'/show'})
                            this.statusmessages.push("Registration Successfull!")
                            this.isSuccess=true
                        },
                        err=>{
                            console.log(err)
                        })
          }
          else
          {
              this.isSuccess=false
          }
      },
      validateinputs: function(){
           if(this.user.username.trim() =="" || this.user.email.trim() ==""|| this.user.password.trim() =="")
           {
            this.statusmessages.push("Please provide all mandatory fields.")
            return false;
           }
           return true;
      }
  }
}
</script>